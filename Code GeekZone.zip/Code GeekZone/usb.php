<html lang="fr">

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" media="screen" type="text/css" title="style" href="style.css"/>
  <center><B><U><font size="40" color="#74BA41"face="sans-serif">USB</B></U></center></font>
  <title>GeekZone</title>
</head>

</head>

<body>

<?php include 'inc/minibox.php' ?>
<?php include 'inc/fonctions.php' ?>

<div class="titrePage">
<center><font size="40" color="#74BA41"face="sans-serif"><B><U>USB </U></B></font></center> </div>
  <div class="rectangle"></div>
  <div class="ligne1"></div>
  <div class="ligne2"></div>
  <div class="ligne3"></div>
  <div class="ligne4"></div>

  <div class="chauffe"><p class="nom1">
  Chauffe-tasse biscuit</p><img name="slide" width="256" height="256" /> <p class="mil1">
  Rien ne vaut que de traîner sur ses sites préférés en compagnie d'un breuvage bien tiède juste à côté de vous.<br>Un chocolat ? Un thé ? Un café ? Ce chauffe-tasse tout mignon en forme de petit gâteau gardera votre boisson bien au chaud jusqu'à 50° !</br></p>
  <p class="prixusb"> 12,90 € </p></div>

  <div class="frigo"><p class="nom2">
  Frigo </p><img name="slide2" width="256" height="256" /> <p class="mil2">
  Avouez qu'il est très désagréable, en plein été, d'aller se servir une canette fraîche dans le frigo de la cuisine, et de la voir se réchauffer très rapidement sur le bureau. 
  Cette tracasserie est maintenant finie grâce à ce frigo USB...
</p><p class="prixusb"> 22,90 € </p></div>

  <div class="ventilateur"><p class="nom3">
  Ventilateur Lumineux  </p><img name="slide3" width="256" height="256" /> <p class="mil3">
  Un ventilateur USB avec tige flexible, idéal pour une utilisation sur un ordinateur portable. Petit plus : des LEDs incrustées pour une ambiance hors du commun.
</p><p class="prixusb">8,90 €</p> </div>


  <div class="mini"><p class="nom4">
  Mini Aspirateur </p><img name="slide4" width="256" height="256" /> <p class="mil4">
  Fini les miettes de pain et autres poussières incrustées dans votre clavier, grâce à ce mini aspirateur USB. Accessoire bien pratique ! 
   </p><p class="prixusb"> 9,90 € </p></div>

  <script>
    var i = 0;
    var j = 2;
    var k = 4;
    var l = 6; // Start Point
    var images = []; // Images Array
    var time = 2000; // Time Between Switch

    // Image List
    images[0] = "images/USB/chauffe-tasse-biscuit-usb.jpg";
    images[1] = "images/USB/chauffe-tasse-biscuit-usb-1.jpg";
    images[2] = "images/USB/frigo-usb.jpg";
    images[3] = "images/USB/frigo-usb-1.jpg" ;
    images[4] = "images/USB/ventilateur-lumineux-usb.jpg";
    images[5] = "images/USB/ventilateur-lumineux-usb-1.jpg";
    images[6] = "images/USB/mini-aspirateur-usb.jpg";

    // Run function when page loads
    window.onload = changeImgUSB;

  </script>

</body>

</html>