<script>

function changeImgGadgets() {
      document.slide.src = images[i];
      document.slide2.src = images[j];
      document.slide3.src = images[k];
      document.slide4.src = images[l];

      // Check If Index Is Under Max
      if (i < 2) {
        // Add 1 to Index
        i++;
      } else {
        // Reset Back To O
        i = 0;
      }
      if (j < 4) {
        // Add 1 to Index
        j++;
      } else {
        // Reset Back To 3
        j = 3;
      }
      if (k < 6) {
        // Add 1 to Index
        k++;
      } else {
        // Reset Back To 5
        k = 5;
      }
      if (l < 7) {
        // Add 1 to Index
        l++;
      } else {
        // Reset Back To 7
        l = 7;
      }


      // Run function every x seconds
      setTimeout("changeImgGadgets()", time);
    }
</script>



<script>

function changeImgPortable() {
      document.slide.src = images[i];
      document.slide2.src = images[j];
      document.slide3.src = images[k];

      // Check If Index Is Under Max
      if (i < 1) {
        // Add 1 to Index
        i++;
      } else {
        // Reset Back To O
        i = 0;
      }
      if (j < 4) {
        // Add 1 to Index
        j++;
      } else {
        // Reset Back To 2
        j = 2;
      }
      if (k < 6) {
        // Add 1 to Index
        k++;
      } else {
        // Reset Back To 5
        k = 5;
      }

      // Run function every x seconds
      setTimeout("changeImgPortable()", time);
    }
</script>


<script>
function changeImgMode() {
      document.slide.src = images[i];
      document.slide2.src = images[j];
      document.slide3.src = images[k];
      document.slide4.src = images[l];

      // Check If Index Is Under Max
      if (i < 1) {
        // Add 1 to Index
        i++;
      } else {
        // Reset Back To O
        i = 0;
      }
      if (j < 3) {
        // Add 1 to Index
        j++;
      } else {
        // Reset Back To 3
        j = 2;
      }
      if (k < 6) {
        // Add 1 to Index
        k++;
      } else {
        // Reset Back To 5
        k = 4;
      }
      if (l < 8) {
        // Add 1 to Index
        l++;
      } else {
        // Reset Back To 7
        l = 7;
      }


      // Run function every x seconds
      setTimeout("changeImgMode()", time);
    }

  </script>


<script>
function changeImgUSB() {
      document.slide.src = images[i];
      document.slide2.src = images[j];
      document.slide3.src = images[k];
      document.slide4.src = images[l];

      // Check If Index Is Under Max
      if (i < 1) {
        // Add 1 to Index
        i++;
      } else {
        // Reset Back To O
        i = 0;
      }
      if (j < 3) {
        // Add 1 to Index
        j++;
      } else {
        // Reset Back To 3
        j = 2;
      }
      if (k < 5) {
        // Add 1 to Index
        k++;
      } else {
        // Reset Back To 5
        k = 4;
      }
      if (l < 6) {
        // Add 1 to Index
        l++;
      } else {
        // Reset Back To 7
        l = 6;
      }


      // Run function every x seconds
      setTimeout("changeImgUSB()", time);
    }
    </script>

<script>
function changeImgCui() {
      document.slide.src = images[i];
      document.slide2.src = images[j];
      document.slide3.src = images[k];
     

      // Check If Index Is Under Max
      if (i < 1) {
        // Add 1 to Index
        i++;
      } else {
        // Reset Back To O
        i = 0;
      }
      if (j < 4) {
        // Add 1 to Index
        j++;
      } else {
        // Reset Back To 3
        j = 2;
      }
      if (k < 5) {
        // Add 1 to Index
        k++;
      } else {
        // Reset Back To 5
        k = 5;
      }


      // Run function every x seconds
      setTimeout("changeImgCui()", time);
    }
</script>