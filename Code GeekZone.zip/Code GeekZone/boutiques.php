<html>

    <?php include 'inc/minibox.php' ?>

<head>
<div class="titrePage">
<center><B><font size="40" color="#74BA41"face="sans-serif"><U>BOUTIQUES </U></B></font></center>
		<link rel="stylesheet" media="screen" type="text/css" title="style" href="style.css"/>
</div>
<title>GeekZone</title>
    </head>
<body>

<table class="tableBoutiques">
<tr>
<td>Albertville<br/>32 Rue Gambetta<br/>73200<br/>04 56 10 36 89 </td>
<td> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2826.15466023877!2d4.885489815770025!3d44.899849478942265!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f5580698598377%3A0x8eac8e10a32c2fb0!2s84+Route+de+Beauvallon%2C+26000+Valence!5e0!3m2!1sfr!2sfr!4v1553073298067" 
    width="300" height="225" frameborder="0" style="border:0" allowfullscreen></iframe> </td>
<td> <img class="boutique1"
     src="images/boutiques/boutique_albertville.jpg" 
     style="width:480px;height:320px;"/> </td>
</tr>


<tr>
<td> <img class="boutique2"
     src="images/boutiques/boutique_annecy.jpg" /> </td>
<td> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d777.7318272321614!2d2.461650107129978!3d49.030222820079985!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6400e9cc0598d%3A0x1bebc184155c2c8d!2s46+Avenue+de+Gen%C3%A8ve%2C+95190+Goussainville!5e0!3m2!1sfr!2sfr!4v1553075816917" 
    width="300" height="225" frameborder="0" style="border:0" allowfullscreen></iframe> </td>
<td>Annecy<br/>46 Avenue de Genève<br/>74000<br/>04 50 57 01 13 </td>
</tr>

<tr>
<td>Chambery<br/>32 Rue Jean Pierre Veyrat<br/>73000<br/>04 79 85 19 96 </td>
<td> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2793.2231767211324!2d5.9150725157862265!3d45.56595043466882!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478ba855fe76659f%3A0xfc0459fdd33fdcc1!2s32+Rue+Jean+Pierre+Veyrat%2C+73000+Chamb%C3%A9ry!5e0!3m2!1sfr!2sfr!4v1553075964585" 
    width="300" height="255" frameborder="0" style="border:0" allowfullscreen></iframe> </td>
<td> <img class="boutique3"
     src="images/boutiques/boutique_chambery.jpg" 
     style="width:281px;height:365px;"/> </td>
</tr>

<tr>
<td> <img class="boutique4"
     src="images/boutiques/boutique_clermont.jpeg" 
     style="width:400px;height:266px;"/> </td>
     <td> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1391.3778755836745!2d3.086270026303441!3d45.77608500946431!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f71be865d512bd%3A0x8d6562ed3b5cee46!2s11bis+Rue+Saint-Esprit%2C+63000+Clermont-Ferrand!5e0!3m2!1sfr!2sfr!4v1553076101798" 
        width="300" height="255" frameborder="0" style="border:0" allowfullscreen></iframe>
<td>Clermont Ferrand<br/>11bis Rue Saint-Esprit<br/>74000<br/>09 83 70 11 98 </td>
</tr>

<tr>
<td>Grenoble<br/>2bis Avenue St Roch<br/>38000<br/>04 76 54 33 47 </td>
<td> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2811.7279539272376!2d5.737279415777125!3d45.192602959545454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478af4f5fc4f49b7%3A0x7614d92c982aea6d!2s2+Avenue+Saint-Roch%2C+38000+Grenoble!5e0!3m2!1sfr!2sfr!4v1553076183868" 
    width="300" height="255" frameborder="0" style="border:0" allowfullscreen></iframe> </td>
<td> <img class="boutique5"
     src="images/boutiques/boutique_grenoble.jpg" 
     style="width:425px;height:291px;"/> </td>
</tr>

<tr>
<td> <img class="boutique6"
     src="images/boutiques/boutique_lyon.jpg" 
     style="width:512px;height:341.5px;"/> </td>
<td> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2783.5441533781286!2d4.828838615790948!3d45.76028392165828!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f4ea5493c45429%3A0x1f23691fee7853de!2sBistrot+Des+C%C3%A9lestins!5e0!3m2!1sfr!2sfr!4v1553076265283" 
    width="300" height="255" frameborder="0" style="border:0" allowfullscreen></iframe> </td>
<td>Lyon<br/>7 Quai des Célestins<br/>69002<br/>04 72 19 68 68 </td>
</tr>

<tr>
<td>Valence<br/>84 Route Beauvallon<br/>26000<br/>04 75 56 27 77 </td>
<td> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2826.15466023877!2d4.885489815770025!3d44.899849478942265!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f5580698598377%3A0x8eac8e10a32c2fb0!2s84+Route+de+Beauvallon%2C+26000+Valence!5e0!3m2!1sfr!2sfr!4v1553076441098" 
    width="300" height="255" frameborder="0" style="border:0" allowfullscreen></iframe> </td>
<td> <img class="boutique7"
     src="images/boutiques/boutique_valence.jpg" 
     style="width:480px;height:360px;"/> </td>
</tr>

</table>

<footer>
<div class="rectangle"> </div>
</footer>