<html lang="fr">

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" media="screen" type="text/css" title="style" href="style.css"/>
  <div class="titrePage">
<center><font size="40" color="#74BA41"face="sans-serif"><B><U>CUISINE</U></B></font></center> </div>
<title>GeekZone</title>
</head>

</head>

<body>

<?php include 'inc/minibox.php' ?>
<?php include 'inc/fonctions.php' ?>

  <div class="ligne1"></div>
  <div class="ligne2"></div>
  <div class="ligne3"></div>
  <div class="ligne4"></div>

  <div class="fridgebook"><p class="nomCui1">
  Magnets fridgebook</p><img name="slide" width="256" height="256" /> <p class="milCui1">
  Recréez l'environnement de votre réseau social préféré ... sur votre frigo ! grâce à nos magnets fridgebook.<br> Mettez à jour votre statut et commentaires à l'aide du stylo feutre fourni.</br> </p>  
  <p class="prixCui"> 14,90 € </p></div>

  <div class="glacons"><p class="nomCui2">
  Glaçon tétris </p><img name="slide2" width="256" height="256" /> <p class="milCui2">
  Plongez ces glaçons Tetris dans votre verre et ceux de vos amis pour recréer des parties interminables ! 
  <br>Un élément geek indispensable pour passer une bonne soirée à se remémorer les jeux de votre enfance ! Regardez les glaçons s'imbriquer les uns sur les autres tout en buvant votre breuvage bien frais.</br>
  </p><p class="prixCui"> 8,90 € </p></div>

  <div class="mug"><p class="nomCui3">
  Mug pac-man chaud froid </p><img name="slide3" width="256" height="256" /> <p class="milCui3">
  Fan de Pac-Man, ce mug est fait pour vous ! Froid, c'est une grille de jeu Pac-Man... Chaud,<br> Pac-Man, les fantômes et les Pac-Gommes apparaissent ! </br></p>
  <p class="prixCui"> 9,90 €</p> </div>

  <script>
    var i = 0;
    var j = 2;
    var k = 5;
    var images = []; // Images Array
    var time = 2000; // Time Between Switch

    // Image List
    images[0] = "images/cuisine/fridgebook-magnet-reseau-social-frigo.jpg";
    images[1] = "images/cuisine/fridgebook-magnet-reseau-social-frigo-1.jpg";
    images[2] = "images/cuisine/glacons-tetris.jpg";
    images[3] = "images/cuisine/glacons-tetris-1.jpg" ;
    images[4] = "images/cuisine/glacons-tetris-2.jpg";
    images[5] = "images/cuisine/mug-pac-man-chaud-froid.jpg";

    // Run function when page loads
    window.onload = changeImgCui;

  </script>

</body>

<footer>
<div class="rectangle"> </div>
</footer>

</html>