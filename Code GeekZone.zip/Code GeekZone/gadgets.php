<html lang="fr">

<head>
  <link rel="stylesheet" href="style.css">
  <meta charset="UTF-8">
  <title>GeekZone</title>
</head>

<body>
  <?php include 'inc/minibox.php' ?>
  <?php include 'inc/fonctions.php' ?>
  
  <div class="titrePage">
<center><font size="40" color="#74BA41"face="sans-serif"><B><U>GADGETS </U></B></font></center> </div>
  <div class="ligne1"></div>
  <div class="ligne2"></div>
  <div class="ligne3"></div>
  <div class="ligne4"></div>

  <div class="gadget1"><p class="titre1g">
    Prise chargeur USB robinet</p><img name="slide" width="256" height="256" /> <p class="milieu1g">
  Un chargeur USB totalement geek pour votre smartphone ?</p><p class="prix1g">24,90€</p></div>
  <div class="gadget2"><p class="titre2g">
    Souris Optique Pixel</p><img name="slide2" width="256" height="256" /> <p class="milieu2g">
  Fatigué de votre banale souris ? Adoptez cette souris optique filaire en forme d'icône géante de pointeur de souris !
</p><p class="prix2g">17,90€</p></div>
  <div class="gadget3"><p class="titre3g">
    Stealth Switch</p><img name="slide3" width="256" height="256" /> <p class="milieu3g">
  Vous souhaitiez vous offrir quelques minutes relax ? Le Stealth Switch sera votre arme fatale !
</p><p class="prix3g">45,90€</p> </div>
  <div class="gadget4"><p class="titre4g">
    Powerball</p><img name="slide4" width="256" height="256" /> <p class="milieu4g">
  Le Powerball est un nouveau gyroscope totalement révolutionnaire tenant dans la main <br />et capable de générer une énorme quantité d'énergie
  et un couple extraordinaire<br /> quand vous activez son rotor interne.  </p><p class="prix4g">35,00€</p></div>

  <script>
    var i = 0;
    var j = 3;
    var k = 5;
    var l = 7; // Start Point
    var images = []; // Images Array
    var time = 2000; // Time Between Switch

    // Image List
    images[0] = "images/gadget/prise-chargeur-usb-robinet-2.jpg";
    images[1] = "images/gadget/prise-chargeur-usb-robinet-1.jpg";
    images[2] = "images/gadget/prise-chargeur-usb-robinet.jpg";
    images[3] = "images/gadget/souris-optique-pixel-1.jpg";
    images[4] = "images/gadget/souris-optique-pixel.jpg";
    images[5] = "images/gadget/stealth-switch.jpg";
    images[6] = "images/gadget/stealth-switch-1.jpg";
    images[7] = "images/gadget/powerball.jpg";    

    // Run function when page loads
    window.onload = changeImgGadgets;

  </script>

<footer>
<div class="rectangle"> </div>
</footer>

</body>

</html>
