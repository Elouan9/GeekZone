<html lang="fr">

<head>
  <link rel="stylesheet" href="style.css">
  <meta charset="UTF-8">
  <title>GeekZone</title>
</head>


<body>
  <?php include 'inc/minibox.php' ?>
  <?php include 'inc/fonctions.php' ?>
  
  <div class="titrePage">
<center><font size="40" color="#74BA41"face="sans-serif"><B><U>MODE</U></B></font></center> </div>

  <div class="rectangle"></div>
  <div class="ligne1"></div>
  <div class="ligne2"></div>
  <div class="ligne3"></div>
  <div class="ligne4"></div>

  <div class="mode1"><p class="titre1m">
    Bonnet barbe</p><img name="slide" width="256" height="256" /> <p class="milieu1m">
  Le bonnet barbe, l'assurance d'une pilosité chaque jour renouvelée</p><p class="prix1m">32,90€</p></div>
  <div class="mode2"><p class="titre2m">
    Tee shirt coder</p><img name="slide2" width="256" height="256" /> <p class="milieu2m">
Coder ? On y perd son latin. </p><p class="prix2m">15,50€</p></div>
  <div class="mode3"><p class="titre3m">
    Tee shirt détecteur wifi</p><img name="slide3" width="256" height="256" /> <p class="milieu3m">
Ce tee-shirt dispose d'un détecteur de signal Wifi, et le fait savoir ! Equipé d'un petit module récepteur,<br />
 vous connaitrez aisément l'intensité du réseau Wifi à votre portée. </p><p class="prix3m">39,90€</p> </div>
  <div class="mode4"><p class="titre4m">
    Tee shirt jeux vidéo</p><img name="slide4" width="256" height="256" /> <p class="milieu4m">
  T-Shirt avec un bien beau slogan spécial gamer : Les Jeux Vidéo ont ruiné ma vie : Il m'en reste deux ! </p><p class="prix4m">17,90€</p></div>

  <script>
    var i = 0;
    var j = 2;
    var k = 5;
    var l = 7; // Start Point
    var images = []; // Images Array
    var time = 2000; // Time Between Switch

    // Image List
    images[0] = "images/mode/bonnet-barbe.jpg";
    images[1] = "images/mode/bonnet-barbe-1.jpg";
    images[2] = "images/mode/t-shirt-coder.jpg";
    images[3] = "images/mode/t-shirt-coder-1.jpg";
    images[4] = "images/mode/t-shirt-detecteur-wifi.jpg";
    images[5] = "images/mode/t-shirt-detecteur-wifi-1.jpg";
    images[6] = "images/mode/t-shirt-detecteur-wifi-2.jpg";
    images[7] = "images/mode/t-shirt-les-jeux-video-ont-ruine-ma-vie.jpg";
    images[8] = "images/mode/t-shirt-les-jeux-video-ont-ruine-ma-vie-1.jpg";

    // Run function when page loads
    window.onload = changeImgMode;

  </script>

</body>

</html>
