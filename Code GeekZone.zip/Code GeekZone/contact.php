<!DOCTYPE html>
<html lang="fr">
<head>
  <link rel="stylesheet" href="style.css">
  <meta charset="UTF-8">
  <title>GeekZone</title>
</head>
<body>

<?php include 'inc/minibox.php' ?>
  <h1>
    <div class="titrePage">
  <center><font size="40" color="#74BA41"face="sans-serif"><B><U>NOUS CONTACTER</U></B></font></center>
  </div>
</h1>
    <h3 class="adresse">Adresse</h3>
      <div class="renseignement">Quelque part en France</div>
    <h3 class="email">Email</h3>
      <div class="renseignement">GeekZone@contact.fr</div>
    <h3 class="telephone">Telephone</h3>
      <div class="renseignement">+33 1 02 03 04 05</div>

    <div class="formulaire">
        <form>
        <input type="text" required name="Nom" minlength="4" placeholder="Votre nom" />
      <input type="email" required name="Email" placeholder="Votre adresse mail" />
      <textarea name="Message" required minlength="10" maxlength="200" placeholder="Votre Message"></textarea>
      <input type="submit" value="Envoyer" />
      <input type="reset" value="Effacer" />
      </form>
    </div>
</body>

<footer>
<div class="rectangle"> </div>
</footer>
</html>
