<head>
        <link rel="stylesheet" href="style.css" />
        <title>GeekZone</title>
</head>

<div class="logo">
<img src="images/logo.png" style="width:300px;height:300px;"/>
</div>


<body>
<div class="titre">
<?php echo('GEEKZONE') ?>
</div>

<div class="soustitre" ?>
<?php echo('Le Numéro 1 des Objets Geeks en ligne') ?>
</div>

<?php include 'inc/navbox.php' ?>
</body>

<footer>
<div class="rectangle"> </div>
</footer>