<html>

    <?php include 'inc/minibox.php' ?>

<head>
<div class="titrePage">
<center><font size="40" color="#74BA41"face="sans-serif"><B><U>PORTABLE </U></B></font></center> </div>
<link rel="stylesheet" media="screen" type="text/css" title="style" href="style.css"/>
<title>GeekZone</title>
</head>

<body>
    <?php include 'inc/fonctions.php' ?>
  
  <div class="ligne1"></div>
  <div class="ligne2"></div>
  <div class="ligne3"></div>
  <div class="ligne4"></div>

    <div class="portable1"><p class="titre1p">
    Mini ventilateur pour iPhone</p><img name="slide" width="256" height="256" /> <p class="milieu1p">
    Le ventilateur iphone est le gadget à emporter partout avec vous !</p>
    <p class="prix1p">9,95€</p></div>
  <div class="portable2"><p class="titre2p">
    Coque IPhone 4 décapsuleur</p><img name="slide2" width="256" height="256" /> <p class="milieu2p">
    Avec cette coque intelligente concue avec undécapsuleur, vous serez toujours prêt à ouvrir votre boisson préférée!
</p><p class="prix2p">26,90€</p></div>
  <div class="portable3"><p class="titre3p">
    Manette jeu pour écran tactile 'Istick'</p><img name="slide3" width="256" height="256" /> <p class="milieu3p">
    Le stick qui transforme votre smartphone en console portable
</p><p class="prix3p">10,90€</p> </div>

<script>
    var i = 0;
    var j = 2;
    var k = 5; // Start Point
    var images = []; // Images Array
    var time = 2000; // Time Between Switch

    // Image List
    images[0] = "images/portable/ventilo-pour-iphone.jpg";
    images[1] = "images/portable/ventilo-pour-iphone-1.jpg";
    images[2] = "images/portable/coque-iphone-4-decapsuleur.jpg";
    images[3] = "images/portable/coque-iphone-4-decapsuleur-1.jpg";
    images[4] = "images/portable/coque-iphone-4-decapsuleur-2.jpg";
    images[5] = "images/portable/manette-jeu-pour-ecran-tactile-istick.jpg";
    images[6] = "images/portable/manette-jeu-pour-ecran-tactile-istick-1.jpg";

    // Run function when page loads
    window.onload = changeImgPortable;

    </script>

<footer>
<div class="rectangle"> </div>
</footer>

</html>