<?php $page = $_SERVER['PHP_SELF'];?>

<nav class="minibox">
<table>
	<td <?php if(strpos($page,'index.php')) echo ' class="active"'; ?>> <a href="index.php">Accueil</a> </td>
	<td <?php if(strpos($page,'catalogue.php')) echo ' class="active"'; ?>> <a href="catalogue.php">Catalogue</a> </td>
	<td <?php if(strpos($page,'boutiques.php')) echo ' class="active"'; ?>> <a href="boutiques.php">Nos Boutiques</a> </td>
    <td <?php if(strpos($page,'contact.php')) echo ' class="active"'; ?>> <a href="contact.php">Contact</a> </td>
</table>
</nav>