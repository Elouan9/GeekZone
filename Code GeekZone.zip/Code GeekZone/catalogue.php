<html>
	<?php include 'inc/minibox.php' ?>
<head>

<div class="titrePage">
<center><B><font size="40" color="#74BA41"face="sans-serif"><U>CATALOGUE </U></font></center>
		<link rel="stylesheet" media="screen" type="text/css" title="style" href="style.css"/>
</div>
<title>GeekZone</title>
</head>

<body>

<div class="cuisine">
<a href="cuisine.php">CUISINE</a>
</div>
<div class="usb">
<a href="usb.php">USB</a>
</div>
<div class="mode">
<a href="mode.php">MODE</a>
</div>
<div class="portable">
<a href="portable.php">PORTABLE</a>
</div>
<div class="gadgets">
<a href="gadgets.php">GADGETS</a>
</div>

</body>
</B>


<footer>
<div class="rectangle"> </div>
</footer>


</div>
</html>
